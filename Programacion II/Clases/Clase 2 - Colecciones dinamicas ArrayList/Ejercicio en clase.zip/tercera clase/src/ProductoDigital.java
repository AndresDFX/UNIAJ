public class ProductoDigital extends Producto {

    // 1. ATRIBUTOS - Caracteristicas (OPCIONAL) - siempre son privados o protegidos
    String plataforma;


    // 2. CONSTRUCTOR (OBLIGATORIO EN HERENCIA)
    public ProductoDigital(int id, String nombre, double precioBase, String plataforma){
        super(id, nombre, precioBase); // Solo los del constructor de la clase PADRE
        this.plataforma = plataforma; // Este es de la clase en la que estoy
    }

    // 3. METODOS - Acciones (OPCIONAL)
    // 3.1 Getters and Setters

    // 3.2 Metodos "Normales"
    @Override
    public double calcularPrecioFinal(){
        return this.precioBase + 10.5;
    }


}
