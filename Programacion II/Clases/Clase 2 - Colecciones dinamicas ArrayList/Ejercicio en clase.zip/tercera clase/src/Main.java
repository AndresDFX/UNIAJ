public class Main{
    public static void main(String[] args){
        // 1. Como creo un variable de tipo ProductoDigital? (Int, String)
        ProductoDigital miProductoDigital = new ProductoDigital(1, "Teclado", 500.2, "Zoom");

        // 1.1 como creo un variable de tipo Entero?
        // tipo nombreVariable = valor
        System.out.println(miProductoDigital.calcularPrecioFinal());
        
        // ToDo
        // 1. Terminar la clase ProductoFisico
        // 2. Crear un objeto de la clase ProductoFisico 


    }


}