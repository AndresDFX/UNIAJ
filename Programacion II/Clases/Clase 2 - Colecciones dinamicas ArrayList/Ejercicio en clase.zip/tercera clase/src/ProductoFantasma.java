public class ProductoFantasma {
    
}
