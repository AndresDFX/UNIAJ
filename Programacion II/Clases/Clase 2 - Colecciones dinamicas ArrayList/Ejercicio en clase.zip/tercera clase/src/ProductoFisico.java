public class ProductoFisico {
    
}
