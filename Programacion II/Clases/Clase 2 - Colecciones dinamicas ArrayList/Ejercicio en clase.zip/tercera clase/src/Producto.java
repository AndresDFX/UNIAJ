public class Producto{  // clases siempre publicas
    // 1. ATRIBUTOS - Caracteristicas (OPCIONAL) - siempre son privados o protegidos
    private int id;
    private String nombre;
    protected double precioBase;

    // 2. CONSTRUCTOR (OPCIONAL)
    public Producto(int id, String nombre, double precioB){
        this.id = id;
        this.nombre = nombre;
        precioBase = precioB;
    }

    // 3. METODOS - Acciones (OPCIONAL)
    // 3.1 Getters and Setters
    public String getNombre(){
        return this.nombre;
    }

    // 3.2 Metodos "Normales"
    public double calcularPrecioFinal(){
        return this.precioBase;
    }
}